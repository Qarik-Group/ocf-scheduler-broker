package ginkgoreporter // import "code.cloudfoundry.org/lager/ginkgoreporter"
