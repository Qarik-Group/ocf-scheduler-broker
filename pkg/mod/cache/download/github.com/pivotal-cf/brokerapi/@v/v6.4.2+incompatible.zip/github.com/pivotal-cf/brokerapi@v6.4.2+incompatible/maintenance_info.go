package brokerapi

import (
	"github.com/pivotal-cf/brokerapi/domain"
)

//Deprecated: Use github.com/pivotal-cf/brokerapi/domain
type MaintenanceInfo = domain.MaintenanceInfo
