package main // import "code.cloudfoundry.org/lager/lagerflags/integration"
